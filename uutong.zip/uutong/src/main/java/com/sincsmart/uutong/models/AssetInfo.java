package com.sincsmart.uutong.models;

import com.jfinal.plugin.activerecord.Model;

@SuppressWarnings("serial")
public class AssetInfo extends Model<AssetInfo>{

	public static final AssetInfo me = new AssetInfo();
}
