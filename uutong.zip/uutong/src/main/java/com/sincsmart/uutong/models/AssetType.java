package com.sincsmart.uutong.models;

import com.jfinal.plugin.activerecord.Model;

@SuppressWarnings("serial")
public class AssetType extends Model<AssetType>{

	public static final AssetType me = new AssetType();
}
