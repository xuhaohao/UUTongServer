package com.sincsmart.uutong.asset;

import java.io.Serializable;

public class AppAsset implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String name;
	
}
