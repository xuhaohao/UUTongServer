package com.sincsmart.uutong.models;

import com.jfinal.plugin.activerecord.Model;

@SuppressWarnings("serial")
public class ClassInfo extends Model<ClassInfo>{

	public static final ClassInfo me = new ClassInfo();
	
	
}
