package com.sincsmart.uutong.models;

import com.jfinal.plugin.activerecord.Model;

@SuppressWarnings("serial")
public class NewsInfo extends Model<NewsInfo>{

	public static final NewsInfo me = new NewsInfo();
	
	
}
