package com.sincsmart.uutong.rongmodels;

//消息基类，如实现自定义消息，可继承此类
public class Message {

	protected String type;

	public String getType() {
		return type;
	}	
}
