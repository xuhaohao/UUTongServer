package com.sincsmart.uutong.asset;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.jfinal.core.Controller;

public class AssetController extends Controller{

	private static final Logger log = LogManager.getLogger(AssetController.class);


}
