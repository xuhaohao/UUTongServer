package com.sincsmart.uutong.common;

public class R {

	public static final String Identity_Parent = "家长";
	public static final String Identity_Teacher = "教师";
	public static final String Identity_Principal = "校长";
	
			
}
