package com.sincsmart.uutong.models;

import com.jfinal.plugin.activerecord.Model;

public class SchoolInfo extends Model<SchoolInfo> {

	public static final SchoolInfo me = new SchoolInfo();
}
