package com.sincsmart.uutong.models;

import com.jfinal.plugin.activerecord.Model;

@SuppressWarnings("serial")
public class NewsDetail extends Model<NewsDetail>{

	public static final NewsDetail me = new NewsDetail();
}
