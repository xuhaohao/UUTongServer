package com.sincsmart.uutong.utils;

import com.jfinal.plugin.activerecord.Model;
import com.sincsmart.uutong.models.UserInfo;

public class PropertyCloneUtil {

	public static <T> void copy(Model model,T t){
		
	}
}
